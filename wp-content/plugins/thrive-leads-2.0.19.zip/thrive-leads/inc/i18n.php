<?php
$d = 'thrive-leads';

return array(
	'state_missing' => __( 'Please select a state', $d ),
);
