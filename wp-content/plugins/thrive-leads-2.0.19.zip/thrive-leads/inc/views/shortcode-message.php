<style>
	.tl-shortcode-notif {
		padding: 10px;
		max-width: 800px;
		margin: 20px auto;
		background: white;
		box-shadow: 1px 1px 2px 0px rgba(0, 0, 0, .25);
		text-align: center;
	}
	.tl-shortcode-notif p {
		margin: 0 !important;
		padding: 0 !important;
		color: #0a0a0a !important;
		font-size: 12px !important;
	}
</style>
<div class="tl-shortcode-notif"><p><?php echo __( 'Thrive Leads Shortcodes will not be rendered outside the content area when editing a Page with Thrive Architect', 'thrive-leads' ) ?></p></div>